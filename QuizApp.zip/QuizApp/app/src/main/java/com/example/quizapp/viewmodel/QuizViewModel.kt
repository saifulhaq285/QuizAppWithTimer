package com.example.quizapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizapp.model.Question
import com.example.quizapp.repository.QuestionRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class QuizViewModel : ViewModel() {
    val questions: List<Question> = QuestionRepository.getQuestions()
    var currentQuestionIndex by mutableStateOf(0)
    var selectedOptionIndex by mutableStateOf<Int?>(null)
    var score by mutableStateOf(0)
    var quizFinished by mutableStateOf(false)
    var timeLeft by mutableStateOf(10)

    private var timerRunning = false

    init {
        startTimer()
    }

    fun getCurrentQuestion(): Question = questions[currentQuestionIndex]

    fun onOptionSelected(index: Int?) {
        selectedOptionIndex = index
        if (index != null && index == getCurrentQuestion().correctAnswerIndex) {
            score++
        }
        goToNextQuestionWithDelay()
    }

    private fun goToNextQuestionWithDelay() {
        timerRunning = false
        viewModelScope.launch {
            delay(1000)
            if (currentQuestionIndex < questions.lastIndex) {
                currentQuestionIndex++
                selectedOptionIndex = null
                timeLeft = 10
                startTimer()
            } else {
                quizFinished = true
            }
        }
    }

    private fun startTimer() {
        timerRunning = true
        val startTime = System.currentTimeMillis()
        val endTime = startTime + 10_000

        viewModelScope.launch {
            while (timerRunning) {
                val currentTime = System.currentTimeMillis()
                val remainingTime = ((endTime - currentTime) / 1000).toInt().coerceAtLeast(0)
                timeLeft = remainingTime

                if (remainingTime == 0) {
                    timerRunning = false
                    onOptionSelected(null)
                }

                delay(250)
            }
        }
    }

    fun resetQuiz() {
        currentQuestionIndex = 0
        selectedOptionIndex = null
        score = 0
        quizFinished = false
        timeLeft = 10
        startTimer()
    }
}