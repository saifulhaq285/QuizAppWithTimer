package com.example.quizapp.model

data class Question(
    val text: String,
    val options: List<String>,
    val correctAnswerIndex: Int
)