package com.example.quizapp.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.quizapp.viewmodel.QuizViewModel

@Composable
fun QuizScreen(navController: NavController, viewModel: QuizViewModel = viewModel()) {
    val question = viewModel.getCurrentQuestion()
    val selectedOptionIndex = viewModel.selectedOptionIndex
    val timeLeft = viewModel.timeLeft

    // Navigate to result screen if quiz finished
    if (viewModel.quizFinished) {
        LaunchedEffect(Unit) {
            navController.navigate("result")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D47A1), Color(0xFF42A5F5))
                )
            )
            .padding(WindowInsets.safeDrawing.asPaddingValues())
            .padding(16.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = "Question ${viewModel.currentQuestionIndex + 1}/${viewModel.questions.size}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            LinearProgressIndicator(
                progress = timeLeft / 10f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = Color.Yellow
            )

            Text(
                text = question.text,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White
            )

            question.options.forEachIndexed { index, option ->
                val isSelected = selectedOptionIndex == index
                Button(
                    onClick = { viewModel.onOptionSelected(index) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0xFF1976D2) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(text = option)
                }
            }

            Text(
                text = "Time left: $timeLeft sec",
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
