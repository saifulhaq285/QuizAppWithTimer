package com.example.quizapp.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.quizapp.viewmodel.QuizViewModel

@Composable
fun ResultScreen(navController: NavController, viewModel: QuizViewModel = viewModel()) {
    val totalQuestions = viewModel.questions.size
    val score = viewModel.score

    val message = when {
        score <= 2 -> "Bad luck! 😢"
        score == 3 -> "Not bad! 🙂"
        else -> "Well done! 👍"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF4A148C), // Deep Purple
                        Color(0xFF6A1B9A), // Purple
                        Color(0xFF8E24AA)  // Lighter Purple
                    )
                )
            )
            .padding(WindowInsets.safeDrawing.asPaddingValues())
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Quiz Finished!",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Your Score: $score / $totalQuestions",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = if (score > 3) MaterialTheme.colorScheme.primary
            else if (score == 3) Color.Yellow
            else MaterialTheme.colorScheme.error
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                viewModel.resetQuiz()
                navController.navigate("quiz") {
                    popUpTo("home") { inclusive = false }
                }
            }
        ) {
            Text("Play Again")
        }
    }
}