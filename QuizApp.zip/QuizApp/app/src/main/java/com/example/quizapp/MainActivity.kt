package com.example.quizapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.quizapp.screens.HomeScreen
import com.example.quizapp.screens.QuizScreen
import com.example.quizapp.screens.ResultScreen
import com.example.quizapp.ui.theme.QuizAppTheme
import com.example.quizapp.viewmodel.QuizViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuizAppTheme {
                val navController = rememberNavController()
                val quizViewModel = remember { QuizViewModel() }

                NavHost(navController = navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(navController)
                    }
                    composable("quiz") {
                        QuizScreen(navController, quizViewModel)
                    }
                    composable("result") {
                        ResultScreen(navController, quizViewModel)
                    }
                }
            }
        }
    }
}
