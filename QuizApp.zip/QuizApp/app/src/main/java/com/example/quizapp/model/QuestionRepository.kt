package com.example.quizapp.repository

import com.example.quizapp.model.Question

object QuestionRepository {
    fun getQuestions(): List<Question> {
        return listOf(
            Question("What is the capital of France?", listOf("Paris", "London", "Rome", "Berlin"), 0),
            Question("Which planet is known as the Red Planet?", listOf("Earth", "Mars", "Jupiter", "Venus"), 1),
            Question("Who wrote Hamlet?", listOf("Shakespeare", "Wordsworth", "Dickens", "Austen"), 0),
            Question("What is the chemical symbol for water?", listOf("H2O", "CO2", "NaCl", "O2"), 0),
            Question("What is the largest mammal?", listOf("Elephant", "Whale", "Giraffe", "Hippo"), 1)
        )
    }
}